		var iden = false;
		var iden_shop=true;
		var slideIndex = 1;
		window.onload=func;
		function func()
		{
			if(iden==true)
			{
				iden=false;
				document.getElementById("butto").innerHTML='<input type="text" style="font-family: sans-serif; padding-down:20px; padding-left:130px; background-color: white; padding-top:40px;"  placeholder="What can we hep you find.." name="Search"><button style="font-size:24px ; cursor: pointer; background-color: white; border:none; float:right; padding-left:60px ; padding-right:50px; padding-top:40px" onclick="func()"><i class="fa fa-window-close-o" style="font-size:36px"></i></button>';
			}
			else
			{
				iden=true;
				document.getElementById("butto").innerHTML='<button style="font-size:24px ; cursor: pointer; background-color: white; border:none; float:right; padding-left:60px ; padding-right:50px; padding-top:40px" onclick="func()"><i class="fa fa-search"></i></button>';
				currentSlide(1);
			}
		}
 
		function login_fn() {
		  document.getElementById("myModal").style.display = "block";
		}
		function close_fn() {
		  document.getElementById("myModal").style.display = "none";
		}
		window.onclick = function(event) {
		  if (event.target == document.getElementById("myModal")) {
		    document.getElementById("myModal").style.display = "none";
		  }
		}

		function shop_fn() {
			if(iden_shop==true)
			{
		  		iden_shop=false;
		  		document.getElementById("id_shop_modal").style.display="block";
			}
			else
			{
				iden_shop=true;
				document.getElementById("id_shop_modal").style.display="none";
			}
		}
		function price_drop_down(){
             document.getElementById("price_drop_down_id").style.display="block";
             document.getElementById("open1").innerHTML='<button style=" float:right; background:none;border:none; " onclick="close_price_drop_down()"><i class="fa fa-sort-asc" style="font-size:25px;"></i></button>';
		}
		function close_price_drop_down(){
			document.getElementById("price_drop_down_id").style.display="none";
			document.getElementById("open1").innerHTML='<button style=" float:right; background:none;border:none; " onclick="price_drop_down()"><i class="fa fa-sort-desc" style="font-size:25px;"></i></button>';

		}